import java.util.Scanner;

public class Calculadora {

    public static void main(String[] args) {
        Calculadora calc = new Calculadora();
        Scanner scanner = new Scanner(System.in);
        String nombre = "Mi nombre";

        System.out.println(" Bienvenido a la Calculadora de " + nombre);
        System.out.print("Introduce la operación (sumar, restar, multiplicar, dividir): ");
        String operador = scanner.nextLine().toLowerCase();

        System.out.print("Introduce el primer número: ");
        int a = scanner.nextInt();

        System.out.print("Introduce el segundo número: ");
        int b = scanner.nextInt();

        try {
            int resultado = calc.operarRefactorizado(operador, a, b);
            System.out.println(" Resultado: " + resultado);
        } catch (Exception e) {
            System.out.println("️ Error: " + e.getMessage());
        }
    }
    /* Este metodo realiza una operacion determinada con los valores a y b dependiendo del String operador
    @author Joan
    @date 12/05/2025
    @param operador
    @param a
    @param b
    @version 1.0
    @deprecated usar el metodo operarRefactorizado
     */
    public int operarRefactorizado(String operador, int a, int b) {
        System.out.println(" Iniciando operación: " + operador.toUpperCase());
        switch (operador){
            case "sumar":
                return a + b;
            case "restar":
                return a - b;
            case "multiplicar":
                return a * b;
            case "dividir":
                if (b == 0) {
                    throw new ArithmeticException("División por cero");
                }
                return a / b;
            case null, default:
                System.out.println("⚠️ Error: Operación no válida");
                return 0;
        }
    }

    /*@Test
    void null
    Calculadora = new Calculadora;
    int resultado = null;
    int a = null;
    int b = null;
    */
}